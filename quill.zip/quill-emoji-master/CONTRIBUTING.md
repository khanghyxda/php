# Contributing

## Building

To build __quill-emoji__, run the following command:

```sh
yarn
yarn build
```

## Testing

Still need to add testing

## Releases

Still need to come up with release schemes

## Maintainers

__@yeminhtut__  
__@himynameistimli__
